public interface ICard {
    public boolean isExpired();
}