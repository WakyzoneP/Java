import java.io.*;
import java.net.*;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class TCPServerSocketMultiT {
    private ServerSocket socket;
    private int port = 50001;
    private File f;
    private VectThread vt;

    public TCPServerSocketMultiT(int port) throws Exception {
        socket = new ServerSocket(port);
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setFileName(String newFName) {
        if (newFName != null)
            f = new File(newFName);
        else
            f = null;
    }

    // c.4.- public void startTCPServer() throws IOException method which is having
    // the infinite processing loop and is implementing 3 commands from the
    // proprietary protocol
    // HINTS for startTCPServer method:
    // -create multi-threading by using lambda expressions from Runnable functional
    // interface after the blocking accept() method from serverSocket object
    // -get the input stream as BufferedReader and output stream as
    // ObjectOutputStream
    // -initialize the vt field from class VectThread by passing the file absolute
    // path from f field as parameters AND OBTAIN the list (ArrayList of Phone
    // objects) from the file
    // -parse line by line the TCP request
    // - if EXIT text command is received over the socket, then break the infinite
    // loop of the processing and send TCP FIN packet back to the TCP client (e.g.
    // by closing socket, etc.)
    // - (mark 6) if GETFILE text command is received over the socket, then reply
    // back the serialized list encapsulated in the vt object field
    // - (mark 7) if GETJSON text command is received over the socket, then reply
    // back with the list in JSON format
    // - (mark 8) if GETDB text command is received over the socket, then reply back
    // with the list as String produced by UtilsDAO.selectData() (please also take
    // into account, you have to initialize JDBC connection and close it with static
    // methods from UtilsDAO);
    // YOU MAY NOT create the TCP client because it is already created into JUnit
    // test framework; for mark 8, please also see UtilsDAO class (without UtilsDAO
    // class, mark 8 can not be achieved)

    public void startTCPServer() throws IOException {

        Socket client = socket.accept();
        System.out.println("Client connected");

        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());

        Thread t = new Thread(vt);
        t.start();

        vt = new VectThread(f.getAbsolutePath());
        List<Phone> phoneList = vt.getPhoneList().stream().map(x -> (Phone) x).toList();

        while (true) {
            String line = in.readLine();
            if (line.equals("EXIT")) {
                break;
            } else if (line.equals("GETFILE")) {
                out.writeObject(phoneList);
            } else if (line.equals("GETJSON")) {
                {
                    JSONArray jsonArray = new JSONArray();
                    for(var phone : phoneList)
                    {
                        try {
                            JSONObject json = new JSONObject();
                            json.put("weight", phone.getWeight());
                            json.put("diagonal", phone.getDiagonal());
                            json.put("producer", phone.getProducer());
                        } catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                        
                    }
                }
            } else if (line.equals("GETDB")) {
                // out.writeObject(UtilsDAO.selectData());
            }
        }

        client.close();
    }
}
