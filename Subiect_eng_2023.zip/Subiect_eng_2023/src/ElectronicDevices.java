public interface ElectronicDevices {
    public String infoDevice();
}
