import java.sql.Connection;

public class UtilsDAO {
    private static Connection c;
    public static void setConnection()
    {
        
    }
}
